		Fraud Archive Reporting Service (FARS) (H140) - XML Schema Package
		==================================================================

Developed in 3/2020 for Hub Sprint 99.

This service is a consolidated version of two previously separate services: FARS and DE FARS. This 
XML Schema will be used to validate both FARS and DE FARS payloads.