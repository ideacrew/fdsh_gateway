		Remote Identify Proofing (RIDP) (H139) - XML Schema Package
		===========================================================

Developed in 3/2020 for Hub Sprint 99.

This service is a consolidated version of two previously separate services: RIDP and DE RIDP. This 
XML Schema will be used to validate both RIDP and DE RIDP payloads.